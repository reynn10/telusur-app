package com.telusur.ui.report

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.telusur.app.R
import androidx.core.content.ContextCompat
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.telusur.ui.report.adapter.LaporanAdapter
import com.telusur.ui.report.model.Laporan

class RiwayatLaporanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_riwayat_laporan)

        window.statusBarColor = ContextCompat.getColor(this, R.color.dark_blue)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerRiwayatLaporan)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Data dummy untuk riwayat laporan
        val riwayatData = listOf(
            Laporan(R.drawable.ic_jalan_rusak, "Jalan Rusak RT 03", "Lubang besar di tengah jalan.", "8 Juni 2025", "Selesai"),
            Laporan(R.drawable.ic_sampah, "Tumpukan Sampah", "Sampah menumpuk di pinggir jalan.", "6 Juni 2025", "Selesai"),
            Laporan(R.drawable.ic_lampu, "Lampu Jalan Mati", "Lampu mati sejak 3 hari lalu.", "5 Juni 2025", "Selesai")
        )
        val adapter = LaporanAdapter(riwayatData)
        recyclerView.adapter = adapter

        // Tombol kembali
        findViewById<View>(R.id.btnBack).setOnClickListener {
            finish()
        }
    }
} 