package com.telusur.ui.report.model

data class Laporan(
    val iconResId: Int,
    val title: String,
    val desc: String,
    val date: String,
    val status: String
)
