package com.telusur.ui.info.model

data class Info(
    val imageResId: Int,
    val title: String,
    val date: String,
    val description: String
)
