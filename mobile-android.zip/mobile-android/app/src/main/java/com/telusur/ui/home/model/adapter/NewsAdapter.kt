package com.telusur.ui.home.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.telusur.app.R
import com.telusur.ui.home.model.News

class NewsAdapter(private val newsList: List<News>) :
    RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    class NewsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.news_title)
        val date: TextView = view.findViewById(R.id.news_date)
        val author: TextView = view.findViewById(R.id.news_author)
        val description: TextView = view.findViewById(R.id.news_description)
        val image: ImageView = view.findViewById(R.id.news_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_news, parent, false)
        return NewsViewHolder(view)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        val news = newsList[position]
        holder.title.text = news.title
        holder.date.text = news.date
        holder.author.text = news.author
        holder.description.text = news.description
        holder.image.setImageResource(news.imageRes)
    }

    override fun getItemCount(): Int = newsList.size
}
