package com.telusur.ui.report

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.telusur.app.R
import androidx.core.content.ContextCompat

class BuatLaporanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buat_laporan)

        window.statusBarColor = ContextCompat.getColor(this, R.color.dark_blue)
    }
} 