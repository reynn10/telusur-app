package com.telusur.ui.report

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.telusur.app.R
import androidx.core.content.ContextCompat
import android.view.View
import android.content.Intent
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.telusur.ui.home.HomeActivity
import com.telusur.ui.info.InfoActivity
import com.telusur.ui.profile.ProfileActivity
import com.telusur.ui.report.adapter.LaporanAdapter
import com.telusur.ui.report.model.Laporan

class LaporanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_laporan)

        window.statusBarColor = ContextCompat.getColor(this, R.color.dark_blue)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerLaporan)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Data dummy untuk daftar laporan
        val dummyData = listOf(
            Laporan(R.drawable.ic_jalan_rusak, "Jalan Rusak RT 03", "Lubang besar di tengah jalan.", "8 Juni 2025", "Menunggu"),
            Laporan(R.drawable.ic_sampah, "Tumpukan Sampah", "Sampah menumpuk di pinggir jalan.", "6 Juni 2025", "Diproses"),
            Laporan(R.drawable.ic_lampu, "Lampu Jalan Mati", "Lampu mati sejak 3 hari lalu.", "5 Juni 2025", "Selesai")
        )
        val adapter = LaporanAdapter(dummyData)
        recyclerView.adapter = adapter

        // Tombol Buat Laporan
        findViewById<View>(R.id.btnBuatLaporan).setOnClickListener {
            startActivity(Intent(this, BuatLaporanActivity::class.java))
        }

        // Tombol Riwayat Laporan
        findViewById<View>(R.id.btnRiwayatLaporan).setOnClickListener {
            startActivity(Intent(this, RiwayatLaporanActivity::class.java))
        }

        // Bottom Navigation
        findViewById<View>(R.id.nav_home).setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        findViewById<View>(R.id.nav_laporan).setOnClickListener {
            val intent = Intent(this, LaporanActivity::class.java)
            startActivity(intent)
        }

        findViewById<View>(R.id.nav_informasi).setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.nav_profile).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}