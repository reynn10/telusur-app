package com.telusur.ui.profile

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import com.telusur.app.R
import com.telusur.utils.SessionManager
import com.telusur.ui.login.LoginActivity
import com.telusur.ui.home.HomeActivity
import com.telusur.ui.info.InfoActivity
import com.telusur.ui.report.LaporanActivity

class ProfileActivity : AppCompatActivity() {
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        window.statusBarColor = ContextCompat.getColor(this, R.color.dark_blue)

        sessionManager = SessionManager(this)

        val nameView = findViewById<TextView>(R.id.profileName)
        val emailView = findViewById<TextView>(R.id.profileEmail)
        val logoutBtn = findViewById<Button>(R.id.logoutButton)

        nameView.text = sessionManager.fetchUserName() ?: "Tidak diketahui"
        emailView.text = sessionManager.fetchUserEmail() ?: "Tidak diketahui"

        logoutBtn.setOnClickListener {
            sessionManager.clearToken()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            Toast.makeText(this, "Logout berhasil", Toast.LENGTH_SHORT).show()
        }

        // Bottom Navigation
        findViewById<View>(R.id.nav_home).setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        findViewById<View>(R.id.nav_laporan).setOnClickListener {
            val intent = Intent(this, LaporanActivity::class.java)
            startActivity(intent)
        }

        findViewById<View>(R.id.nav_informasi).setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.nav_profile).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}
