package com.telusur.data.network

import com.telusur.data.model.User
import retrofit2.http.*
import retrofit2.Response

interface ApiService {
    @FormUrlEncoded
    @POST("api/login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): User
}
