// File: mobile-android/app/src/main/java/com/telusur/app/MainActivity.kt
// TELUSUR - Android App (Kotlin + Jetpack Compose)
// Tampilan Beranda, Laporan Baru, dan Riwayat Laporan

package com.telusur.app

import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.telusur.ui.theme.TelusurTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TelusurTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    TelusurHome()
                }
            }
        }
    }
}

@Composable
fun TelusurHome() {
    var currentTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Beranda", "Lapor", "Riwayat")

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text(label) },
                        selected = currentTab == index,
                        onClick = { currentTab = index }
                    )
                }
            }
        }
    ) {
        Box(modifier = Modifier.padding(it)) {
            when (currentTab) {
                0 -> HomeScreen()
                1 -> LaporanBaruScreen()
                2 -> RiwayatScreen()
            }
        }
    }
}

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Selamat Datang di TELUSUR", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Pengumuman Terkini:", fontWeight = FontWeight.SemiBold)
        Text("- Bansos tahap 2 mulai 10 Juni 2025")
        Text("- Gotong royong Sabtu ini pukul 07:00 WIB")
    }
}

@Composable
fun LaporanBaruScreen() {
    var judul by remember { mutableStateOf("") }
    var deskripsi by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Formulir Laporan Baru", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(value = judul, onValueChange = { judul = it }, label = { Text("Judul") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = deskripsi,
            onValueChange = { deskripsi = it },
            label = { Text("Deskripsi") },
            modifier = Modifier.height(100.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = { /* kirim laporan */ }, modifier = Modifier.align(Alignment.End)) {
            Text("Kirim")
        }
    }
}

@Composable
fun RiwayatScreen() {
    val laporan = listOf(
        Laporan("Jalan Berlubang", "Diproses", "2025-06-01"),
        Laporan("Sampah menumpuk", "Selesai", "2025-06-02")
    )

    LazyColumn(modifier = Modifier.padding(16.dp)) {
        items(laporan) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(item.judul, fontWeight = FontWeight.Bold)
                    Text("Status: ${item.status}", color = Color.Blue)
                    Text("Tanggal: ${item.tanggal}")
                }
            }
        }
    }
}

data class Laporan(val judul: String, val status: String, val tanggal: String)
