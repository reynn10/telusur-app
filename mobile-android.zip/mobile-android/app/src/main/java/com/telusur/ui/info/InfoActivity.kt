package com.telusur.ui.info

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.telusur.app.R
import com.telusur.ui.home.HomeActivity
import com.telusur.ui.profile.ProfileActivity
import com.telusur.ui.report.LaporanActivity
import com.telusur.ui.info.adapter.InfoAdapter
import com.telusur.ui.info.model.Info

class InfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)

        window.statusBarColor = ContextCompat.getColor(this, R.color.dark_blue)

        val recycleView = findViewById<RecyclerView>(R.id.recyclerInfo)
        recycleView.layoutManager = LinearLayoutManager(this)

        val dummyData = listOf(
            Info(R.drawable.ic_gotong_royong, "Kegiatan Gotong Royong", "08 Juni 2025", "Bersama warga membersihkan lingkungan."),
            Info(R.drawable.ic_bantuan_pangan, "Penyaluran Bantuan Pangan", "05 Juni 2025", "Distribusi sembako dari pemerintah."),
            Info(R.drawable.ic_dana_bansos, "Penyaluran Dana Bansos", "03 Juni 2025", "Dana bantuan tunai tahap kedua.")
        )
        recycleView.adapter = InfoAdapter(dummyData)

        findViewById<View>(R.id.nav_home).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.nav_laporan).setOnClickListener {
            startActivity(Intent(this, LaporanActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.nav_informasi).setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.nav_profile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
            finish()
        }
    }
}
