package com.telusur.ui.home.model

data class News(
    val title: String,
    val date: String,
    val author: String,
    val description: String,
    val imageRes: Int
)
