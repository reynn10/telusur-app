package com.telusur.ui.report.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.telusur.app.R
import com.telusur.ui.report.model.Laporan

class LaporanAdapter(private val laporanList: List<Laporan>) : RecyclerView.Adapter<LaporanAdapter.LaporanViewHolder>() {

    inner class LaporanViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.laporanIcon)
        val title: TextView = view.findViewById(R.id.laporanTitle)
        val desc: TextView = view.findViewById(R.id.laporanDesc)
        val date: TextView = view.findViewById(R.id.laporanDate)
        val status: TextView = view.findViewById(R.id.laporanStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LaporanViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_laporan, parent, false)
        return LaporanViewHolder(view)
    }

    override fun onBindViewHolder(holder: LaporanViewHolder, position: Int) {
        val laporan = laporanList[position]
        holder.icon.setImageResource(laporan.iconResId)
        holder.title.text = laporan.title
        holder.desc.text = laporan.desc
        holder.date.text = laporan.date
        holder.status.text = laporan.status
    }

    override fun getItemCount(): Int = laporanList.size
}
