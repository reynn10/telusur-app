package com.telusur.ui.info.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.telusur.app.R
import com.telusur.ui.info.model.Info

class InfoAdapter(private val data: List<Info>) :
    RecyclerView.Adapter<InfoAdapter.InfoViewHolder>() {

    class InfoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image: ImageView = itemView.findViewById(R.id.infoImage)
        val title: TextView = itemView.findViewById(R.id.infoTitle)
        val date: TextView = itemView.findViewById(R.id.infoDate)
        val desc: TextView = itemView.findViewById(R.id.infoDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InfoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_info, parent, false)
        return InfoViewHolder(view)
    }

    override fun onBindViewHolder(holder: InfoViewHolder, position: Int) {
        val item = data[position]
        holder.image.setImageResource(item.imageResId)
        holder.title.text = item.title
        holder.date.text = item.date
        holder.desc.text = item.description
    }

    override fun getItemCount(): Int = data.size
}
