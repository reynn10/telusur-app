package com.telusur.ui.login

import androidx.lifecycle.*
import com.telusur.data.model.User
import com.telusur.data.network.ApiClient
import com.telusur.utils.SessionManager
import kotlinx.coroutines.launch

class LoginViewModel(private val sessionManager: SessionManager) : ViewModel() {

    private val _loginResult = MutableLiveData<User?>()
    val loginResult: LiveData<User?> = _loginResult

    fun login(email: String, password: String) {
        viewModelScope.launch {
            try {
                val user = ApiClient.apiService.login(email, password)
                sessionManager.saveAuthToken(user.token)
                sessionManager.saveUserName(user.name)
                _loginResult.value = user
            } catch (e: Exception) {
                _loginResult.value = null
            }
        }
    }
}
