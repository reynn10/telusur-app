package com.telusur.ui.home

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.view.View
import android.widget.Toast
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.telusur.app.R
import com.telusur.ui.home.adapter.NewsAdapter
import com.telusur.ui.home.model.News
import com.telusur.ui.info.InfoActivity
import com.telusur.utils.SessionManager
import com.telusur.ui.report.LaporanActivity
import com.telusur.ui.profile.ProfileActivity

class HomeActivity : AppCompatActivity() {
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        window.statusBarColor = ContextCompat.getColor(this, R.color.dark_blue)

        sessionManager = SessionManager(this)
        val userName = sessionManager.fetchUserName() ?: "Pengguna"

        val greetingText: TextView = findViewById(R.id.greetingText)
        val searchIcon: ImageView = findViewById(R.id.searchIcon)

        // Tampilkan nama pengguna
        greetingText.text = getString(R.string.greeting, userName)

        // Dummy data berita
        val newsList = listOf(
            News(
                title = "BKAD Ketanggungan Mengadakan Bintek Perencanaan dan Pembangunan Desa Berbasis Data",
                date = "03 September 2020",
                author = "admin",
                description = "Forum Badan Kerjasama Antar Desa Ketanggungan Kabupaten Brebes mengadakan...",
                imageRes = R.drawable.bkad
            ),
            News(
                title = "Mengenal Kecamatan Ketanggungan",
                date = "17 Agustus 2020",
                author = "admin",
                description = "Ketanggungan adalah sebuah kecamatan di Brebes...",
                imageRes = R.drawable.kecamatan
            ),
            News(
                title = "GOW dan Baznas Brebes Bantu Korban Banjir di Ketanggungan",
                date = "17 Agustus 2020",
                author = "admin",
                description = "Bantuan korban banjir di lima desa...",
                imageRes = R.drawable.baznas
            )
        )

        val newsRecyclerView: RecyclerView = findViewById(R.id.recyclerNews)
        newsRecyclerView.layoutManager = LinearLayoutManager(this)
        newsRecyclerView.adapter = NewsAdapter(newsList)

        // Bottom Navigation
        findViewById<View>(R.id.nav_home).setOnClickListener {
            Toast.makeText(this, "Beranda", Toast.LENGTH_SHORT).show()
        }

        findViewById<View>(R.id.nav_laporan).setOnClickListener {
            val intent = Intent(this, LaporanActivity::class.java)
            startActivity(intent)
        }

        findViewById<View>(R.id.nav_informasi).setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.nav_profile).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
    }
}
