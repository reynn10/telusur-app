package com.telusur.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("telusur_prefs", Context.MODE_PRIVATE)

    fun saveAuthToken(token: String) {
        val editor = prefs.edit()
        editor.putString("AUTH_TOKEN", token)
        editor.apply()
    }

    fun fetchAuthToken(): String? {
        return prefs.getString("AUTH_TOKEN", null)
    }

    fun clearToken() {
        prefs.edit().remove("AUTH_TOKEN").apply()
    }

    fun saveUserName(name: String) {
        prefs.edit().putString("USER_NAME", name).apply()
    }

    fun fetchUserName(): String? {
        return prefs.getString("USER_NAME", null)
    }

    fun saveUserEmail(email: String) {
        prefs.edit().putString("USER_EMAIL", email).apply()
    }

    fun fetchUserEmail(): String? {
        return prefs.getString("USER_EMAIL", null)
    }

}
