<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

// Route untuk user login & register (TANPA auth)
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);

// Route untuk mendapatkan user login (dengan auth)
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
